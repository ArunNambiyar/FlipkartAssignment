package fk.sample;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.sun.org.apache.xpath.internal.operations.Equals;

public class Flipkart {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws AWTException, Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ARUN\\eclipse-workspace1\\FlipKartAssignment\\driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//button[@class='_2KpZ6l _2doB4z']")).click();
		driver.findElement(By.name("q")).sendKeys("Ipad");
		Thread.sleep(5000);
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_DOWN);
		r.keyRelease(KeyEvent.VK_DOWN);
		r.keyPress(KeyEvent.VK_DOWN);
		r.keyRelease(KeyEvent.VK_DOWN);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		driver.findElement(By.xpath("//div[text()='Display Size']")).click();
		driver.findElement(By.xpath("//div[text()='10 - 11 Inch']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[text()='APPLE iPad (9th Gen) 64 GB ROM 10.2 inch with Wi-Fi Only (Space Grey)']")).click();
		String handle = driver.getWindowHandle();
		System.out.println(handle);
		Set<String> as = driver.getWindowHandles();
		System.out.println(as);
		for (String s : as) {
			
		if (!handle.equals(s)) {
			driver.switchTo().window(s);	
		}

		}
		driver.findElement(By.xpath("//button[text()='Buy Now']")).click();
		driver.findElement(By.xpath("//input[@maxlength='auto']")).sendKeys("9898989898");
		}

	}


